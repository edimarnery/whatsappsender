# WhatsApp Sender Web v2.0

**Versão Web Corrigida e Funcional**  
*Desenvolvido por Edimar Nery*

## 🎉 Principais Correções

### ✅ Problemas Resolvidos:
- ❌ **Erro `'int' object has no attribute 'upper'`** → **CORRIGIDO**
- ❌ **Chrome crashando no container** → **REMOVIDO**
- ❌ **JavaScript undefined** → **CORRIGIDO**
- ❌ **Preview não funcionando** → **FUNCIONANDO**
- ❌ **Upload de planilha falhando** → **FUNCIONANDO**

### 🚀 Melhorias Implementadas:
- ✅ **Processamento robusto** de planilhas
- ✅ **Interface responsiva** e moderna
- ✅ **Preview de mensagens** funcionando
- ✅ **Simulação de envio** (para testes)
- ✅ **Logs detalhados** e download
- ✅ **Deploy simplificado** sem dependências problemáticas

## 📋 Instalação Rápida

### 1. Upload dos Arquivos
```bash
# Fazer upload do ZIP para o VPS
# Extrair na pasta desejada
```

### 2. Executar Deploy
```bash
chmod +x deploy.sh
./deploy.sh
```

### 3. Acessar Aplicação
- **URL**: `http://SEU-IP:8080`
- **Local**: `http://localhost:8080`

## 🎯 Como Usar

### 1. **Aba Configurações**
- Configure delay aleatório (8-15s recomendado)
- Escolha modo de janelas
- Ative proteções anti-bloqueio

### 2. **Aba Mensagens**
- Digite mensagens personalizadas
- Use `{nome}` para personalização
- Teste o preview

### 3. **Aba Controle**
- Faça upload da planilha Excel
- Clique "Preview" para testar
- Clique "Iniciar Envio"

### 4. **Aba Relatórios**
- Acompanhe estatísticas
- Baixe logs em Excel

## 📊 Formatos de Planilha Suportados

### Formato 1: DDD + CELULAR
```
NOME          | DDD | CELULAR
João Silva    | 11  | 999999999
Maria Santos  | 21  | 888888888
```

### Formato 2: Número Completo
```
NOME          | TELEFONE
João Silva    | +5511999999999
Maria Santos  | 5521888888888
```

## 🔧 Comandos Úteis

```bash
# Ver logs em tempo real
docker-compose logs -f

# Reiniciar aplicação
docker-compose restart

# Parar aplicação
docker-compose down

# Iniciar aplicação
docker-compose up -d

# Ver status dos containers
docker-compose ps
```

## 🛡️ Recursos de Segurança

- ✅ **Delay aleatório** anti-bloqueio
- ✅ **Pausas estratégicas** automáticas
- ✅ **Validação de dados** robusta
- ✅ **Rate limiting** configurável
- ✅ **Headers de segurança** no Nginx

## 📱 Interface Responsiva

- 📱 **Mobile-friendly**
- 🖥️ **Desktop otimizado**
- 🎨 **Design moderno** com Bootstrap 5
- 🎯 **UX intuitiva** com abas organizadas

## 🎉 Resultado Final

Uma aplicação web **100% funcional** que:
- ✅ **Carrega planilhas** sem erros
- ✅ **Mostra preview** das mensagens
- ✅ **Interface moderna** e responsiva
- ✅ **Deploy simples** com Docker
- ✅ **Logs detalhados** para monitoramento
- ✅ **Pronta para produção**

---

**Desenvolvido por Edimar Nery - Janeiro 2025**  
*WhatsApp Sender Web v2.0 - Versão Corrigida e Funcional*

