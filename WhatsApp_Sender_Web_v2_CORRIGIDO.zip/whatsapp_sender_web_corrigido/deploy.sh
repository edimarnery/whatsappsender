#!/bin/bash

# WhatsApp Sender Web - Deploy Script v2.0
# Desenvolvido por Edimar Nery

set -e

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funções de log
info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Banner
echo "========================================"
echo "  WhatsApp Sender Web v2.0 - Deploy"
echo "  Desenvolvido por Edimar Nery"
echo "========================================"
echo

# Verificar se Docker está instalado
if ! command -v docker &> /dev/null; then
    info "Instalando Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    rm get-docker.sh
    success "Docker instalado com sucesso!"
else
    success "Docker já está instalado"
fi

# Verificar se Docker Compose está instalado
if ! command -v docker-compose &> /dev/null; then
    info "Instalando Docker Compose..."
    curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    success "Docker Compose instalado com sucesso!"
else
    success "Docker Compose já está instalado"
fi

# Parar containers existentes
info "Parando containers existentes..."
docker-compose down 2>/dev/null || true

# Limpar imagens antigas
info "Limpando imagens antigas..."
docker system prune -f

# Criar diretórios necessários
info "Criando diretórios..."
mkdir -p uploads logs data

# Construir e iniciar containers
info "Construindo e iniciando aplicação..."
docker-compose up --build -d

# Aguardar containers iniciarem
info "Aguardando containers iniciarem..."
sleep 10

# Verificar status
info "Verificando status dos containers..."
docker-compose ps

# Testar aplicação
info "Testando aplicação..."
if curl -f http://localhost:5000 > /dev/null 2>&1; then
    success "Aplicação está funcionando!"
else
    warning "Aplicação pode não estar respondendo ainda. Aguarde alguns segundos."
fi

# Configurar firewall
if command -v ufw &> /dev/null; then
    info "Configurando firewall..."
    ufw allow 5000 2>/dev/null || true
    ufw allow 8080 2>/dev/null || true
    success "Firewall configurado"
fi

echo
echo "========================================"
echo "  DEPLOY CONCLUÍDO COM SUCESSO!"
echo "========================================"
echo
echo "🌐 Acesse a aplicação em:"
echo "   http://$(hostname -I | awk '{print $1}'):8080"
echo "   http://localhost:8080"
echo
echo "📊 Comandos úteis:"
echo "   docker-compose logs -f    # Ver logs"
echo "   docker-compose restart    # Reiniciar"
echo "   docker-compose down       # Parar"
echo "   docker-compose up -d      # Iniciar"
echo
echo "🎉 WhatsApp Sender Web está pronto para uso!"
echo

