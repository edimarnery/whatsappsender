from flask import Flask, render_template, request, jsonify, send_file
from flask_cors import CORS
import pandas as pd
import os
import json
import time
import threading
from datetime import datetime
import logging
import tempfile
import uuid
import random
from urllib.parse import quote

app = Flask(__name__)
CORS(app)

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Diretórios
UPLOAD_FOLDER = 'uploads'
LOGS_FOLDER = 'logs'
DATA_FOLDER = 'data'

# Criar diretórios se não existirem
for folder in [UPLOAD_FOLDER, LOGS_FOLDER, DATA_FOLDER]:
    os.makedirs(folder, exist_ok=True)

# Estado global da aplicação
app_state = {
    'enviando': False,
    'contatos': [],
    'progresso': 0,
    'total': 0,
    'enviados': 0,
    'erros': 0,
    'status': 'Aguardando...',
    'logs': [],
    'parar_envio': False,
    'mensagens_configuradas': []
}

def processar_planilha(df):
    """Processa planilha e retorna lista de contatos válidos"""
    contatos = []
    
    try:
        logger.info(f"Processando planilha com {len(df)} linhas")
        
        # Converter todas as colunas para string para evitar erros
        for col in df.columns:
            df[col] = df[col].astype(str)
        
        # Detectar formato da planilha
        colunas = [str(col).upper().strip() for col in df.columns]
        logger.info(f"Colunas detectadas: {colunas}")
        
        # Verificar se tem colunas DDD e CELULAR
        has_ddd = any('DDD' in col for col in colunas)
        has_celular = any('CELULAR' in col or 'TELEFONE' in col for col in colunas)
        
        if has_ddd and has_celular:
            # Formato: NOME, DDD, CELULAR
            logger.info("Formato detectado: NOME, DDD, CELULAR")
            
            for index, row in df.iterrows():
                try:
                    # Pegar valores das colunas
                    nome = str(row.iloc[0]).strip()
                    ddd = str(row.iloc[1]).strip()
                    celular = str(row.iloc[2]).strip()
                    
                    # Pular linhas vazias ou cabeçalhos
                    if (nome.lower() in ['nan', 'none', ''] or 
                        'nome' in nome.lower() or 
                        nome == 'NOME'):
                        continue
                    
                    # Limpar e validar DDD
                    ddd = ''.join(filter(str.isdigit, ddd))
                    if len(ddd) != 2:
                        logger.warning(f"DDD inválido para {nome}: {ddd}")
                        continue
                    
                    # Limpar e validar celular
                    celular = ''.join(filter(str.isdigit, celular))
                    if len(celular) < 8 or len(celular) > 9:
                        logger.warning(f"Celular inválido para {nome}: {celular}")
                        continue
                    
                    # Garantir 9 dígitos no celular
                    if len(celular) == 8:
                        celular = '9' + celular
                    
                    numero_completo = f"+55{ddd}{celular}"
                    
                    contatos.append({
                        'nome': nome,
                        'numero': numero_completo,
                        'ddd': ddd,
                        'celular': celular
                    })
                    
                except Exception as e:
                    logger.error(f"Erro ao processar linha {index}: {e}")
                    continue
        
        else:
            # Formato antigo ou auto-detecção
            logger.info("Tentando detectar formato automaticamente...")
            
            for index, row in df.iterrows():
                try:
                    if len(row) >= 2:
                        nome = str(row.iloc[0]).strip()
                        segundo_campo = str(row.iloc[1]).strip()
                        
                        # Pular cabeçalhos e linhas vazias
                        if (nome.lower() in ['nan', 'none', ''] or 
                            'nome' in nome.lower() or 
                            nome == 'NOME'):
                            continue
                        
                        # Limpar segundo campo
                        segundo_limpo = ''.join(filter(str.isdigit, segundo_campo))
                        
                        # Se tem 2 dígitos, pode ser DDD
                        if len(segundo_limpo) == 2 and len(row) >= 3:
                            ddd = segundo_limpo
                            celular = ''.join(filter(str.isdigit, str(row.iloc[2]).strip()))
                            
                            if len(celular) >= 8:
                                if len(celular) == 8:
                                    celular = '9' + celular
                                
                                numero_completo = f"+55{ddd}{celular}"
                                contatos.append({
                                    'nome': nome,
                                    'numero': numero_completo,
                                    'ddd': ddd,
                                    'celular': celular
                                })
                        
                        # Se tem mais de 10 dígitos, é número completo
                        elif len(segundo_limpo) >= 10:
                            if not segundo_limpo.startswith('55'):
                                segundo_limpo = f"55{segundo_limpo}"
                            
                            numero_completo = f"+{segundo_limpo}"
                            contatos.append({
                                'nome': nome,
                                'numero': numero_completo
                            })
                            
                except Exception as e:
                    logger.error(f"Erro ao processar linha {index}: {e}")
                    continue
        
        logger.info(f"Total de contatos processados: {len(contatos)}")
        return contatos
        
    except Exception as e:
        logger.error(f"Erro ao processar planilha: {e}")
        raise Exception(f"Erro ao processar planilha: {e}")

def simular_envio_whatsapp(contatos, mensagens, config):
    """Simula envio de mensagens (versão funcional sem Selenium)"""
    try:
        app_state['enviando'] = True
        app_state['parar_envio'] = False
        app_state['total'] = len(contatos)
        app_state['enviados'] = 0
        app_state['erros'] = 0
        app_state['progresso'] = 0
        app_state['logs'] = []
        
        app_state['status'] = 'Iniciando envios...'
        
        # Delay inicial se configurado
        if config.get('delay_inicial', False):
            delay_inicial = random.randint(5, 15)
            app_state['status'] = f'Delay inicial: aguardando {delay_inicial}s...'
            time.sleep(delay_inicial)
        
        # Simular envios
        for i, contato in enumerate(contatos):
            if app_state['parar_envio']:
                break
            
            try:
                # Selecionar mensagem aleatória
                mensagem = random.choice(mensagens)
                mensagem_personalizada = mensagem.replace('{nome}', contato['nome'])
                
                app_state['status'] = f'Enviando para {contato["nome"]} ({contato["numero"]})...'
                
                # Simular delay de envio
                if config['delay']['tipo'] == 'aleatorio':
                    delay = random.randint(config['delay']['min'], config['delay']['max'])
                else:
                    delay = config['delay']['fixo']
                
                # Simular envio (95% sucesso)
                sucesso = random.random() > 0.05
                
                # Registrar resultado
                log_entry = {
                    'nome': contato['nome'],
                    'numero': contato['numero'],
                    'status': 'Sucesso' if sucesso else 'Erro',
                    'mensagem': 'Enviado com sucesso' if sucesso else 'Erro simulado',
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                
                app_state['logs'].append(log_entry)
                
                if sucesso:
                    app_state['enviados'] += 1
                else:
                    app_state['erros'] += 1
                
                # Atualizar progresso
                app_state['progresso'] = int((i + 1) / len(contatos) * 100)
                
                # Aguardar delay
                app_state['status'] = f'Aguardando {delay}s antes do próximo envio...'
                time.sleep(delay)
                
                # Delay extra a cada 10 envios
                if config.get('delay_extra', False) and (i + 1) % 10 == 0:
                    delay_extra = random.randint(30, 60)
                    app_state['status'] = f'Pausa estratégica: aguardando {delay_extra}s...'
                    time.sleep(delay_extra)
                
            except Exception as e:
                logger.error(f"Erro no envio para {contato['nome']}: {e}")
                app_state['erros'] += 1
                app_state['logs'].append({
                    'nome': contato['nome'],
                    'numero': contato['numero'],
                    'status': 'Erro',
                    'mensagem': str(e),
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                })
        
        # Finalizar
        app_state['status'] = 'Envio concluído!'
        
        # Salvar logs
        salvar_logs()
        
    except Exception as e:
        logger.error(f"Erro na simulação de envio: {e}")
        app_state['status'] = f'Erro: {e}'
    
    finally:
        app_state['enviando'] = False

def salvar_logs():
    """Salva logs em arquivo Excel"""
    try:
        if app_state['logs']:
            df_logs = pd.DataFrame(app_state['logs'])
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"logs/envios_{timestamp}.xlsx"
            df_logs.to_excel(filename, index=False)
            logger.info(f"Logs salvos em: {filename}")
    except Exception as e:
        logger.error(f"Erro ao salvar logs: {e}")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'Nenhum arquivo enviado'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'Nenhum arquivo selecionado'}), 400
        
        if not file.filename.lower().endswith(('.xlsx', '.xls')):
            return jsonify({'error': 'Formato de arquivo não suportado. Use .xlsx ou .xls'}), 400
        
        # Salvar arquivo
        filename = f"{uuid.uuid4()}_{file.filename}"
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        file.save(filepath)
        
        # Processar planilha
        df = pd.read_excel(filepath)
        contatos = processar_planilha(df)
        
        if not contatos:
            return jsonify({'error': 'Nenhum contato válido encontrado na planilha'}), 400
        
        # Salvar contatos no estado da aplicação
        app_state['contatos'] = contatos
        
        return jsonify({
            'success': True,
            'total_contatos': len(contatos),
            'contatos': contatos[:5],  # Primeiros 5 para preview
            'message': f'{len(contatos)} contatos carregados com sucesso!'
        })
        
    except Exception as e:
        logger.error(f"Erro ao processar arquivo: {e}")
        return jsonify({'error': f'Erro ao processar arquivo: {e}'}), 500

@app.route('/preview', methods=['POST'])
def preview_mensagens():
    try:
        data = request.get_json()
        mensagens = data.get('mensagens', [])
        
        if not mensagens:
            return jsonify({'error': 'Nenhuma mensagem fornecida'}), 400
        
        if not app_state['contatos']:
            return jsonify({'error': 'Nenhum contato carregado'}), 400
        
        # Gerar preview com primeiros 3 contatos
        previews = []
        for i, contato in enumerate(app_state['contatos'][:3]):
            mensagem = random.choice(mensagens)
            mensagem_personalizada = mensagem.replace('{nome}', contato['nome'])
            previews.append({
                'nome': contato['nome'],
                'numero': contato['numero'],
                'mensagem': mensagem_personalizada
            })
        
        return jsonify({
            'success': True,
            'previews': previews,
            'total_contatos': len(app_state['contatos']),
            'total_mensagens': len(mensagens)
        })
        
    except Exception as e:
        logger.error(f"Erro no preview: {e}")
        return jsonify({'error': f'Erro no preview: {e}'}), 500

@app.route('/iniciar_envio', methods=['POST'])
def iniciar_envio():
    try:
        if app_state['enviando']:
            return jsonify({'error': 'Envio já está em andamento'}), 400
        
        if not app_state['contatos']:
            return jsonify({'error': 'Nenhum contato carregado'}), 400
        
        data = request.get_json()
        mensagens = data.get('mensagens', [])
        config = data.get('config', {})
        
        if not mensagens:
            return jsonify({'error': 'Nenhuma mensagem fornecida'}), 400
        
        # Iniciar thread de envio
        thread = threading.Thread(
            target=simular_envio_whatsapp,
            args=(app_state['contatos'], mensagens, config)
        )
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'success': True,
            'message': 'Envio iniciado com sucesso!'
        })
        
    except Exception as e:
        logger.error(f"Erro ao iniciar envio: {e}")
        return jsonify({'error': f'Erro ao iniciar envio: {e}'}), 500

@app.route('/parar_envio', methods=['POST'])
def parar_envio():
    try:
        app_state['parar_envio'] = True
        app_state['status'] = 'Parando envio...'
        
        return jsonify({
            'success': True,
            'message': 'Comando de parada enviado!'
        })
        
    except Exception as e:
        logger.error(f"Erro ao parar envio: {e}")
        return jsonify({'error': f'Erro ao parar envio: {e}'}), 500

@app.route('/status')
def get_status():
    return jsonify({
        'enviando': app_state['enviando'],
        'progresso': app_state['progresso'],
        'total': app_state['total'],
        'enviados': app_state['enviados'],
        'erros': app_state['erros'],
        'status': app_state['status'],
        'contatos_carregados': len(app_state['contatos'])
    })

@app.route('/logs')
def get_logs():
    return jsonify({
        'logs': app_state['logs'][-50:],  # Últimos 50 logs
        'total_logs': len(app_state['logs'])
    })

@app.route('/download_logs')
def download_logs():
    try:
        if not app_state['logs']:
            return jsonify({'error': 'Nenhum log disponível'}), 400
        
        # Criar arquivo Excel temporário
        df_logs = pd.DataFrame(app_state['logs'])
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx')
        df_logs.to_excel(temp_file.name, index=False)
        
        return send_file(
            temp_file.name,
            as_attachment=True,
            download_name=f'logs_whatsapp_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx',
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        
    except Exception as e:
        logger.error(f"Erro ao baixar logs: {e}")
        return jsonify({'error': f'Erro ao baixar logs: {e}'}), 500

@app.route('/abrir_whatsapp', methods=['POST'])
def abrir_whatsapp():
    """Endpoint para abrir WhatsApp Web"""
    try:
        return jsonify({
            'success': True,
            'message': 'WhatsApp Web será aberto em uma nova aba',
            'url': 'https://web.whatsapp.com'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)

