# 📋 Guia de Instalação - WhatsApp Sender Web

**Guia Completo para Deploy no VPS Hostinger**

Desenvolvido por **Edimar Nery** | Janeiro 2025

---

## 🎯 **Visão Geral**

Este guia detalha como instalar o WhatsApp Sender Web no seu VPS da Hostinger com Ubuntu. Oferecemos **3 métodos** de instalação para diferentes necessidades.

---

## 🖥️ **Preparação do VPS**

### **1. Acesso ao VPS**

```bash
# Conectar via SSH
ssh root@seu-ip-vps

# Ou com usuário específico
ssh usuario@seu-ip-vps
```

### **2. Atualizar Sistema**

```bash
# Atualizar pacotes
sudo apt update && sudo apt upgrade -y

# Instalar utilitários básicos
sudo apt install -y curl wget git unzip htop nano
```

### **3. Criar Usuário (se necessário)**

```bash
# Criar usuário para aplicação
sudo adduser whatsapp
sudo usermod -aG sudo whatsapp

# Trocar para o usuário
su - whatsapp
```

---

## 🐳 **Método 1: Docker (Recomendado)**

### **Vantagens:**
- ✅ Instalação mais simples
- ✅ Isolamento completo
- ✅ Fácil atualização
- ✅ Backup simplificado

### **Passo a Passo:**

#### **1. Baixar Projeto**
```bash
# Navegar para diretório home
cd ~

# Baixar projeto (substitua pela URL real)
git clone https://github.com/seu-usuario/whatsapp_sender_web.git
cd whatsapp_sender_web

# Ou fazer upload manual dos arquivos
```

#### **2. Executar Deploy Automático**
```bash
# Dar permissão de execução
chmod +x deploy.sh

# Executar instalação
./deploy.sh
```

#### **3. Verificar Instalação**
```bash
# Verificar containers
docker-compose ps

# Verificar logs
docker-compose logs -f whatsapp-sender

# Testar aplicação
curl http://localhost:5000
```

#### **4. Configurar Firewall**
```bash
# Permitir porta 5000
sudo ufw allow 5000

# Ou usar porta 80 (recomendado)
sudo ufw allow 80
sudo ufw allow 443
```

### **Resultado:**
- 🌐 Aplicação: `http://seu-ip:5000`
- 📊 Nginx: `http://seu-ip` (se configurado)

---

## 🐍 **Método 2: Instalação Simples (Python)**

### **Vantagens:**
- ✅ Controle total do ambiente
- ✅ Menor uso de recursos
- ✅ Debugging mais fácil
- ✅ Customização avançada

### **Passo a Passo:**

#### **1. Baixar Projeto**
```bash
cd ~
git clone https://github.com/seu-usuario/whatsapp_sender_web.git
cd whatsapp_sender_web
```

#### **2. Executar Instalação**
```bash
# Dar permissão
chmod +x install_simple.sh

# Executar instalação
./install_simple.sh
```

#### **3. Iniciar Aplicação**
```bash
# Modo interativo (para teste)
./start.sh

# Modo background (para produção)
./start_background.sh
```

#### **4. Configurar como Serviço**
```bash
# Copiar arquivo de serviço
sudo cp whatsapp-sender-web.service /etc/systemd/system/

# Habilitar serviço
sudo systemctl enable whatsapp-sender-web
sudo systemctl start whatsapp-sender-web

# Verificar status
sudo systemctl status whatsapp-sender-web
```

### **Comandos de Controle:**
```bash
# Iniciar
sudo systemctl start whatsapp-sender-web

# Parar
sudo systemctl stop whatsapp-sender-web

# Reiniciar
sudo systemctl restart whatsapp-sender-web

# Ver logs
sudo journalctl -u whatsapp-sender-web -f
```

---

## ⚙️ **Método 3: Instalação Manual**

### **Para Usuários Avançados:**

#### **1. Instalar Dependências**
```bash
# Python 3.11
sudo apt install -y python3.11 python3.11-venv python3.11-dev python3-pip

# Chrome e dependências
wget -q -O - https://dl.google.com/linux/linux_signing_key.pub | sudo apt-key add -
echo "deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main" | sudo tee /etc/apt/sources.list.d/google-chrome.list
sudo apt update
sudo apt install -y google-chrome-stable

# Dependências do Chrome
sudo apt install -y fonts-liberation libasound2 libatk-bridge2.0-0 libdrm2 libxcomposite1 libxdamage1 libxrandr2 libgbm1 libxss1 libnss3
```

#### **2. Configurar Aplicação**
```bash
# Criar diretório
mkdir -p ~/whatsapp_sender_web
cd ~/whatsapp_sender_web

# Criar ambiente virtual
python3.11 -m venv venv
source venv/bin/activate

# Instalar dependências (criar requirements.txt primeiro)
pip install flask flask-cors pandas openpyxl selenium webdriver-manager gunicorn

# Criar estrutura de diretórios
mkdir -p src/templates uploads logs data
```

#### **3. Configurar Arquivos**
```bash
# Copiar arquivos do projeto
# src/main.py
# src/templates/index.html
# requirements.txt
```

#### **4. Iniciar Aplicação**
```bash
# Definir variáveis
export FLASK_APP=src/main.py
export FLASK_ENV=production
export PYTHONPATH=$(pwd)

# Iniciar com Flask (desenvolvimento)
python -m flask run --host=0.0.0.0 --port=5000

# Ou com Gunicorn (produção)
gunicorn --bind 0.0.0.0:5000 --workers 2 src.main:app
```

---

## 🌐 **Configuração de Domínio**

### **1. Configurar DNS**

No painel da Hostinger:
1. Acesse **DNS Zone**
2. Adicione registro **A**:
   - **Name**: `whatsapp` (ou `@` para domínio principal)
   - **Value**: IP do seu VPS
   - **TTL**: 3600

### **2. Configurar Nginx (Docker)**

Editar `nginx.conf`:
```nginx
server {
    listen 80;
    server_name whatsapp.seudominio.com;
    
    location / {
        proxy_pass http://whatsapp-sender:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### **3. Configurar SSL (Let's Encrypt)**

```bash
# Instalar Certbot
sudo apt install certbot python3-certbot-nginx

# Obter certificado
sudo certbot --nginx -d whatsapp.seudominio.com

# Renovação automática
sudo crontab -e
# Adicionar: 0 12 * * * /usr/bin/certbot renew --quiet
```

---

## 🔧 **Configurações Avançadas**

### **1. Otimização de Performance**

#### **Docker:**
```yaml
# docker-compose.yml
services:
  whatsapp-sender:
    deploy:
      resources:
        limits:
          memory: 1G
          cpus: '0.5'
    environment:
      - WORKERS=4
```

#### **Gunicorn:**
```bash
# Mais workers
gunicorn --bind 0.0.0.0:5000 --workers 4 --timeout 120 src.main:app
```

### **2. Monitoramento**

#### **Logs Centralizados:**
```bash
# Configurar logrotate
sudo nano /etc/logrotate.d/whatsapp-sender

# Conteúdo:
/home/whatsapp/whatsapp_sender_web/logs/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 whatsapp whatsapp
}
```

#### **Monitoramento de Recursos:**
```bash
# Instalar htop
sudo apt install htop

# Monitorar em tempo real
htop

# Verificar uso de disco
df -h

# Verificar memória
free -h
```

### **3. Backup Automático**

```bash
# Criar script de backup
nano ~/backup.sh

#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/home/whatsapp/backups"
APP_DIR="/home/whatsapp/whatsapp_sender_web"

mkdir -p $BACKUP_DIR

# Backup dos dados
tar -czf $BACKUP_DIR/whatsapp_backup_$DATE.tar.gz \
    $APP_DIR/uploads \
    $APP_DIR/logs \
    $APP_DIR/data

# Manter apenas últimos 7 backups
find $BACKUP_DIR -name "whatsapp_backup_*.tar.gz" -mtime +7 -delete

# Tornar executável
chmod +x ~/backup.sh

# Agendar no crontab
crontab -e
# Adicionar: 0 2 * * * /home/whatsapp/backup.sh
```

---

## 🛡️ **Segurança**

### **1. Firewall (UFW)**

```bash
# Habilitar UFW
sudo ufw enable

# Regras básicas
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Permitir SSH
sudo ufw allow 22

# Permitir HTTP/HTTPS
sudo ufw allow 80
sudo ufw allow 443

# Permitir aplicação (se necessário)
sudo ufw allow 5000

# Verificar status
sudo ufw status
```

### **2. Fail2Ban**

```bash
# Instalar Fail2Ban
sudo apt install fail2ban

# Configurar
sudo nano /etc/fail2ban/jail.local

[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[sshd]
enabled = true
port = 22
filter = sshd
logpath = /var/log/auth.log

# Reiniciar serviço
sudo systemctl restart fail2ban
```

### **3. Atualizações Automáticas**

```bash
# Instalar unattended-upgrades
sudo apt install unattended-upgrades

# Configurar
sudo dpkg-reconfigure -plow unattended-upgrades

# Verificar configuração
sudo nano /etc/apt/apt.conf.d/50unattended-upgrades
```

---

## 📊 **Verificação da Instalação**

### **1. Testes Básicos**

```bash
# Testar conectividade
curl -I http://localhost:5000

# Testar upload (criar arquivo teste)
curl -X POST -F "file=@test.xlsx" http://localhost:5000/upload

# Verificar logs
tail -f logs/app.log
```

### **2. Testes de Performance**

```bash
# Instalar Apache Bench
sudo apt install apache2-utils

# Teste de carga
ab -n 100 -c 10 http://localhost:5000/

# Monitorar recursos durante teste
htop
```

### **3. Verificar Funcionalidades**

1. **Interface Web**: Acesse `http://seu-ip:5000`
2. **Upload**: Teste upload de planilha Excel
3. **Preview**: Verifique preview de mensagens
4. **Envio**: Teste envio com poucos contatos
5. **Logs**: Verifique geração de logs

---

## 🔄 **Manutenção**

### **1. Atualizações**

#### **Docker:**
```bash
cd ~/whatsapp_sender_web
git pull origin main
docker-compose up --build -d
```

#### **Instalação Simples:**
```bash
cd ~/whatsapp_sender_web
git pull origin main
source venv/bin/activate
pip install -r requirements.txt
sudo systemctl restart whatsapp-sender-web
```

### **2. Limpeza**

```bash
# Limpar logs antigos
find logs/ -name "*.log" -mtime +30 -delete

# Limpar uploads antigos
find uploads/ -name "*.xlsx" -mtime +7 -delete

# Docker: limpar imagens não utilizadas
docker system prune -f
```

### **3. Monitoramento Contínuo**

```bash
# Script de monitoramento
nano ~/monitor.sh

#!/bin/bash
# Verificar se aplicação está rodando
if ! curl -f http://localhost:5000/ >/dev/null 2>&1; then
    echo "Aplicação não está respondendo!"
    # Reiniciar serviço
    sudo systemctl restart whatsapp-sender-web
fi

# Agendar verificação a cada 5 minutos
crontab -e
# Adicionar: */5 * * * * /home/whatsapp/monitor.sh
```

---

## 🆘 **Solução de Problemas**

### **Problemas Comuns:**

#### **1. Aplicação não inicia**
```bash
# Verificar logs
sudo journalctl -u whatsapp-sender-web -f

# Verificar porta em uso
sudo netstat -tlnp | grep :5000

# Verificar permissões
ls -la ~/whatsapp_sender_web/
```

#### **2. Chrome não funciona**
```bash
# Instalar dependências faltantes
sudo apt install -y xvfb

# Testar Chrome
google-chrome --version
google-chrome --headless --no-sandbox --dump-dom https://google.com
```

#### **3. Upload falha**
```bash
# Verificar permissões de diretório
sudo chown -R whatsapp:whatsapp ~/whatsapp_sender_web/uploads/
chmod 755 ~/whatsapp_sender_web/uploads/

# Verificar espaço em disco
df -h
```

#### **4. Performance baixa**
```bash
# Verificar recursos
htop
free -h

# Otimizar configuração
# Aumentar workers do Gunicorn
# Configurar cache
# Otimizar banco de dados
```

---

## 📞 **Suporte Pós-Instalação**

### **Comandos Úteis:**

```bash
# Status geral do sistema
sudo systemctl status whatsapp-sender-web
docker-compose ps
htop

# Logs em tempo real
sudo journalctl -u whatsapp-sender-web -f
docker-compose logs -f
tail -f logs/app.log

# Reiniciar serviços
sudo systemctl restart whatsapp-sender-web
docker-compose restart

# Backup manual
tar -czf backup_$(date +%Y%m%d).tar.gz uploads/ logs/ data/
```

### **Arquivos Importantes:**
- `/etc/systemd/system/whatsapp-sender-web.service` - Serviço systemd
- `~/whatsapp_sender_web/logs/` - Logs da aplicação
- `~/whatsapp_sender_web/uploads/` - Planilhas enviadas
- `~/whatsapp_sender_web/docker-compose.yml` - Configuração Docker

---

## ✅ **Checklist Final**

Após instalação, verificar:

- [ ] Aplicação responde em `http://seu-ip:5000`
- [ ] Upload de planilha funciona
- [ ] Preview de mensagens funciona
- [ ] Logs são gerados corretamente
- [ ] Firewall configurado
- [ ] SSL configurado (se aplicável)
- [ ] Backup automático configurado
- [ ] Monitoramento ativo
- [ ] Documentação salva

---

**🎉 Instalação Concluída com Sucesso!**

*Desenvolvido por Edimar Nery - Janeiro 2025*

