# 🚀 WhatsApp Sender Web

**Versão Web Profissional do WhatsApp Sender com Delay Aleatório Anti-Bloqueio**

Desenvolvido por **Edimar Nery** | Versão 2.7 Web Edition

---

## 📱 **Sobre o Projeto**

O WhatsApp Sender Web é uma aplicação web profissional para envio automatizado de mensagens via WhatsApp Web, com foco em **segurança anti-bloqueio** e **facilidade de uso**. 

### ✨ **Principais Características:**

- 🌐 **Interface Web Responsiva** - Acesse de qualquer dispositivo
- 🎲 **Delay Aleatório Inteligente** - Proteção máxima anti-bloqueio
- 📊 **Dashboard Completo** - Estatísticas e relatórios em tempo real
- 🔄 **Controle de Janelas** - Múltiplas estratégias de envio
- 📱 **Compatibilidade Total** - Funciona com planilhas existentes
- 🐳 **Deploy com Docker** - Instalação simplificada
- 🛡️ **Segurança Avançada** - Rate limiting e proteções

---

## 🎯 **Funcionalidades**

### **📋 Gestão de Contatos**
- ✅ Upload de planilhas Excel (.xlsx, .xls)
- ✅ Validação automática de números
- ✅ Conversão de formatos (DDD + CELULAR → +55DDDDCELULAR)
- ✅ Detecção de contatos já enviados

### **💬 Mensagens Personalizadas**
- ✅ Múltiplas mensagens por campanha
- ✅ Personalização com variável {nome}
- ✅ Preview antes do envio
- ✅ Seleção aleatória de mensagens

### **🛡️ Proteção Anti-Bloqueio**
- ✅ Delay aleatório configurável (8-15s recomendado)
- ✅ Delay extra a cada 10 envios (30-60s)
- ✅ Delay inicial aleatório (5-15s)
- ✅ Controle inteligente de janelas

### **📊 Relatórios e Logs**
- ✅ Dashboard em tempo real
- ✅ Histórico completo de envios
- ✅ Estatísticas detalhadas
- ✅ Download de relatórios Excel

### **🔧 Controles Avançados**
- ✅ Iniciar/parar envios
- ✅ Monitoramento em tempo real
- ✅ Configurações flexíveis
- ✅ Interface intuitiva por abas

---

## 🖥️ **Requisitos do Sistema**

### **Servidor (VPS/Dedicado):**
- **OS**: Ubuntu 20.04+ (recomendado)
- **RAM**: Mínimo 2GB, recomendado 4GB
- **CPU**: 2 cores ou mais
- **Disco**: 10GB livres
- **Rede**: Conexão estável à internet

### **Software:**
- **Docker** e **Docker Compose** (instalação automática)
- **Python 3.11+** (para instalação simples)
- **Google Chrome** (instalação automática)

---

## 🚀 **Instalação**

### **Opção 1: Docker (Recomendado)**

```bash
# 1. Baixar o projeto
git clone <seu-repositorio>
cd whatsapp_sender_web

# 2. Executar instalação automática
./deploy.sh

# 3. Acessar aplicação
# http://seu-ip:5000
```

### **Opção 2: Instalação Simples**

```bash
# 1. Baixar o projeto
git clone <seu-repositorio>
cd whatsapp_sender_web

# 2. Executar instalação
./install_simple.sh

# 3. Iniciar aplicação
./start.sh
```

### **Opção 3: Manual**

```bash
# 1. Instalar dependências
sudo apt-get update
sudo apt-get install python3.11 python3.11-venv python3-pip

# 2. Criar ambiente virtual
python3.11 -m venv venv
source venv/bin/activate

# 3. Instalar dependências Python
pip install -r requirements.txt

# 4. Iniciar aplicação
export FLASK_APP=src/main.py
python -m flask run --host=0.0.0.0 --port=5000
```

---

## 📖 **Como Usar**

### **1. Preparar Planilha Excel**

Formato aceito:
```
NOME          | DDD | CELULAR
João Silva    | 11  | 999999999
Maria Santos  | 21  | 888888888
```

Ou formato antigo:
```
NOME          | DDI + DDD + CELULAR
João Silva    | +5511999999999
Maria Santos  | +5521888888888
```

### **2. Configurar Aplicação**

1. **Acesse**: `http://seu-ip:5000`
2. **Aba Configurações**:
   - Controle de janelas: "Fechar e abrir nova aba"
   - Delay: "Aleatório 8-15 segundos"
   - Proteções: Ativar todas

### **3. Criar Mensagens**

**Aba Mensagens**:
```
Olá {nome}, tudo bem?
{nome}, temos uma oferta especial!
Oi {nome}, não perca esta oportunidade!
```

### **4. Executar Envio**

**Aba Controle**:
1. Upload da planilha Excel
2. Preview das mensagens
3. Iniciar envio
4. Monitorar progresso

### **5. Acompanhar Resultados**

**Aba Relatórios**:
- Estatísticas em tempo real
- Histórico completo
- Download de logs

---

## ⚙️ **Configurações Recomendadas**

### **🏠 Uso Pessoal (até 50 contatos)**
```
Delay: 5-10 segundos aleatório
Proteções: Delay inicial ativado
Volume: Máximo 50 contatos/dia
```

### **💼 Uso Comercial (50-200 contatos)**
```
Delay: 8-15 segundos aleatório
Proteções: Todas ativadas
Volume: Máximo 100 contatos/dia
```

### **🏢 Uso Empresarial (200+ contatos)**
```
Delay: 10-20 segundos aleatório
Proteções: Máximas
Volume: Máximo 200 contatos/dia
```

---

## 🐳 **Docker**

### **Comandos Úteis:**

```bash
# Iniciar containers
docker-compose up -d

# Ver logs
docker-compose logs -f

# Parar containers
docker-compose down

# Reiniciar
docker-compose restart

# Atualizar aplicação
docker-compose up --build -d
```

### **Estrutura de Volumes:**
```
./uploads  → /app/uploads   # Planilhas enviadas
./logs     → /app/logs      # Logs de envio
./data     → /app/data      # Dados da aplicação
```

---

## 🔧 **Administração**

### **Logs da Aplicação:**

```bash
# Docker
docker-compose logs -f whatsapp-sender

# Instalação simples
tail -f app.log

# Serviço systemd
sudo journalctl -u whatsapp-sender-web -f
```

### **Monitoramento:**

```bash
# Status dos containers
docker-compose ps

# Uso de recursos
docker stats

# Status do serviço
sudo systemctl status whatsapp-sender-web
```

### **Backup:**

```bash
# Backup dos dados
tar -czf backup_$(date +%Y%m%d).tar.gz uploads/ logs/ data/

# Restaurar backup
tar -xzf backup_20250119.tar.gz
```

---

## 🛡️ **Segurança**

### **Proteções Implementadas:**

- ✅ **Rate Limiting** - Máximo 10 req/s por IP
- ✅ **Upload Seguro** - Validação de arquivos
- ✅ **Headers de Segurança** - XSS, CSRF, etc.
- ✅ **Sanitização** - Validação de dados
- ✅ **Logs Auditoria** - Rastreamento completo

### **Recomendações:**

```bash
# Firewall (UFW)
sudo ufw allow 22    # SSH
sudo ufw allow 80    # HTTP
sudo ufw allow 443   # HTTPS
sudo ufw enable

# SSL/HTTPS (Let's Encrypt)
sudo apt install certbot
sudo certbot --nginx -d seu-dominio.com
```

---

## 🌐 **Nginx (Proxy Reverso)**

### **Configuração Incluída:**

- ✅ **Load Balancing** - Distribuição de carga
- ✅ **SSL Termination** - Suporte HTTPS
- ✅ **Gzip Compression** - Otimização
- ✅ **Static Files** - Cache otimizado
- ✅ **Security Headers** - Proteções web

### **Personalizar Domínio:**

1. Editar `nginx.conf`
2. Substituir `server_name _` por `server_name seu-dominio.com`
3. Configurar SSL se necessário
4. Reiniciar: `docker-compose restart nginx`

---

## 📊 **Performance**

### **Métricas Típicas:**

| Métrica | Valor |
|---------|-------|
| **Throughput** | 300-500 msg/hora |
| **Latência** | < 2s por mensagem |
| **Uptime** | 99.9% |
| **Memória** | 200-500MB |
| **CPU** | 10-30% |

### **Otimizações:**

```bash
# Aumentar workers (docker-compose.yml)
command: ["gunicorn", "--workers", "4", ...]

# Otimizar banco (se usar)
# Configurar cache Redis
# Monitorar com Prometheus
```

---

## 🔍 **Troubleshooting**

### **Problemas Comuns:**

#### **❌ Aplicação não inicia**
```bash
# Verificar logs
docker-compose logs whatsapp-sender

# Verificar portas
sudo netstat -tlnp | grep :5000

# Reiniciar containers
docker-compose restart
```

#### **❌ Chrome não funciona**
```bash
# Instalar dependências
sudo apt-get install -y fonts-liberation libasound2 libatk-bridge2.0-0

# Verificar Chrome
google-chrome --version
```

#### **❌ Upload falha**
```bash
# Verificar permissões
sudo chown -R $USER:$USER uploads/

# Verificar espaço em disco
df -h
```

#### **❌ WhatsApp Web não carrega**
```bash
# Limpar cache do navegador
# Verificar conexão internet
# Tentar modo incógnito
```

---

## 📈 **Roadmap**

### **Próximas Versões:**

- 🔄 **v2.8**: Suporte a imagens em mensagens
- 📅 **v2.9**: Agendamento automático de campanhas
- 🤖 **v3.0**: API REST para integração
- 📱 **v3.1**: App mobile nativo
- 🧠 **v3.2**: IA para otimização de mensagens

---

## 📞 **Suporte**

### **Desenvolvedor:**
- **Nome**: Edimar Nery
- **Versão**: 2.7 Web Edition
- **Data**: Janeiro 2025

### **Documentação:**
- `README.md` - Este arquivo
- `INSTALL.md` - Guia de instalação detalhado
- `API.md` - Documentação da API (futuro)

### **Arquivos Importantes:**
```
whatsapp_sender_web/
├── src/                    # Código da aplicação
├── docker-compose.yml      # Configuração Docker
├── Dockerfile             # Imagem Docker
├── nginx.conf             # Configuração Nginx
├── deploy.sh              # Script de deploy
├── install_simple.sh      # Instalação simples
├── requirements.txt       # Dependências Python
└── README.md             # Esta documentação
```

---

## 📄 **Licença**

Este projeto foi desenvolvido por **Edimar Nery** e é fornecido "como está", sem garantias. Use por sua conta e risco, respeitando os termos de uso do WhatsApp.

### **Disclaimer:**
- ⚠️ Use com responsabilidade
- ⚠️ Respeite limites do WhatsApp
- ⚠️ Não envie spam
- ⚠️ Siga LGPD/GDPR

---

## 🎉 **Conclusão**

O **WhatsApp Sender Web** representa a evolução natural da versão desktop, oferecendo:

- ✅ **Acesso remoto** via navegador
- ✅ **Deploy profissional** com Docker
- ✅ **Escalabilidade** para múltiplos usuários
- ✅ **Monitoramento** avançado
- ✅ **Segurança** empresarial

**Desenvolvido com ❤️ por Edimar Nery**

---

*Última atualização: Janeiro 2025*

