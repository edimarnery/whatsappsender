#!/bin/bash

# Script de Deploy - WhatsApp Sender Web
# Desenvolvido por Edimar Nery

set -e

echo "=========================================="
echo "  WhatsApp Sender Web - Deploy Script"
echo "  Desenvolvido por Edimar Nery"
echo "=========================================="

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para log
log() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar se está rodando como root
if [[ $EUID -eq 0 ]]; then
   error "Este script não deve ser executado como root"
   exit 1
fi

# Verificar sistema operacional
if [[ ! -f /etc/os-release ]]; then
    error "Sistema operacional não suportado"
    exit 1
fi

source /etc/os-release
if [[ "$ID" != "ubuntu" ]]; then
    error "Este script foi testado apenas no Ubuntu"
    exit 1
fi

log "Sistema detectado: $PRETTY_NAME"

# Verificar se Docker está instalado
if ! command -v docker &> /dev/null; then
    log "Instalando Docker..."
    
    # Atualizar pacotes
    sudo apt-get update
    
    # Instalar dependências
    sudo apt-get install -y \
        apt-transport-https \
        ca-certificates \
        curl \
        gnupg \
        lsb-release
    
    # Adicionar chave GPG do Docker
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
    
    # Adicionar repositório
    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
      $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
    
    # Instalar Docker
    sudo apt-get update
    sudo apt-get install -y docker-ce docker-ce-cli containerd.io
    
    # Adicionar usuário ao grupo docker
    sudo usermod -aG docker $USER
    
    log "Docker instalado com sucesso!"
    warn "Você precisa fazer logout e login novamente para usar Docker sem sudo"
else
    log "Docker já está instalado"
fi

# Verificar se Docker Compose está instalado
if ! command -v docker-compose &> /dev/null; then
    log "Instalando Docker Compose..."
    
    # Baixar Docker Compose
    sudo curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    
    # Dar permissão de execução
    sudo chmod +x /usr/local/bin/docker-compose
    
    log "Docker Compose instalado com sucesso!"
else
    log "Docker Compose já está instalado"
fi

# Criar diretórios necessários
log "Criando diretórios..."
mkdir -p uploads logs data ssl

# Configurar permissões
sudo chown -R $USER:$USER uploads logs data

# Verificar se o arquivo docker-compose.yml existe
if [[ ! -f docker-compose.yml ]]; then
    error "Arquivo docker-compose.yml não encontrado!"
    exit 1
fi

# Parar containers existentes (se houver)
log "Parando containers existentes..."
docker-compose down 2>/dev/null || true

# Construir e iniciar containers
log "Construindo e iniciando containers..."
docker-compose up --build -d

# Aguardar containers iniciarem
log "Aguardando containers iniciarem..."
sleep 10

# Verificar status dos containers
log "Verificando status dos containers..."
docker-compose ps

# Verificar se a aplicação está respondendo
log "Testando aplicação..."
if curl -f http://localhost:5000/ >/dev/null 2>&1; then
    log "✅ Aplicação está funcionando!"
else
    warn "⚠️  Aplicação pode não estar respondendo ainda. Aguarde alguns segundos."
fi

# Mostrar logs
log "Últimos logs da aplicação:"
docker-compose logs --tail=20 whatsapp-sender

echo ""
echo "=========================================="
echo "  🎉 DEPLOY CONCLUÍDO!"
echo "=========================================="
echo ""
echo "📱 WhatsApp Sender Web está rodando em:"
echo "   🌐 http://localhost:5000"
echo "   🌐 http://$(hostname -I | awk '{print $1}'):5000"
echo ""
echo "📋 Comandos úteis:"
echo "   Ver logs:        docker-compose logs -f"
echo "   Parar:          docker-compose down"
echo "   Reiniciar:      docker-compose restart"
echo "   Atualizar:      docker-compose up --build -d"
echo ""
echo "🔧 Desenvolvido por Edimar Nery"
echo "=========================================="

