#!/bin/bash

# Script de Instalação Simples - WhatsApp Sender Web
# Desenvolvido por Edimar Nery

set -e

echo "=========================================="
echo "  WhatsApp Sender Web - Instalação Simples"
echo "  Desenvolvido por Edimar Nery"
echo "=========================================="

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para log
log() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar se está rodando como usuário normal
if [[ $EUID -eq 0 ]]; then
   error "Este script não deve ser executado como root"
   exit 1
fi

# Atualizar sistema
log "Atualizando sistema..."
sudo apt-get update

# Instalar Python 3.11 e pip
log "Instalando Python 3.11..."
sudo apt-get install -y python3.11 python3.11-venv python3.11-dev python3-pip

# Instalar dependências do sistema para Chrome
log "Instalando dependências do Chrome..."
sudo apt-get install -y \
    wget \
    gnupg \
    unzip \
    curl \
    xvfb \
    fonts-liberation \
    libasound2 \
    libatk-bridge2.0-0 \
    libdrm2 \
    libxcomposite1 \
    libxdamage1 \
    libxrandr2 \
    libgbm1 \
    libxss1 \
    libnss3

# Instalar Google Chrome
if ! command -v google-chrome &> /dev/null; then
    log "Instalando Google Chrome..."
    wget -q -O - https://dl.google.com/linux/linux_signing_key.pub | sudo apt-key add -
    echo "deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main" | sudo tee /etc/apt/sources.list.d/google-chrome.list
    sudo apt-get update
    sudo apt-get install -y google-chrome-stable
else
    log "Google Chrome já está instalado"
fi

# Criar ambiente virtual
log "Criando ambiente virtual..."
python3.11 -m venv venv

# Ativar ambiente virtual
log "Ativando ambiente virtual..."
source venv/bin/activate

# Atualizar pip
log "Atualizando pip..."
pip install --upgrade pip

# Instalar dependências Python
log "Instalando dependências Python..."
pip install -r requirements.txt

# Criar diretórios necessários
log "Criando diretórios..."
mkdir -p uploads logs data

# Criar script de inicialização
log "Criando script de inicialização..."
cat > start.sh << 'EOF'
#!/bin/bash

# Script de inicialização - WhatsApp Sender Web
# Desenvolvido por Edimar Nery

echo "Iniciando WhatsApp Sender Web..."

# Ativar ambiente virtual
source venv/bin/activate

# Definir variáveis de ambiente
export FLASK_APP=src/main.py
export FLASK_ENV=production
export PYTHONPATH=$(pwd)

# Iniciar aplicação
echo "Aplicação disponível em: http://localhost:5000"
echo "Para parar, pressione Ctrl+C"
echo ""

python -m flask run --host=0.0.0.0 --port=5000
EOF

chmod +x start.sh

# Criar script de inicialização em background
log "Criando script para rodar em background..."
cat > start_background.sh << 'EOF'
#!/bin/bash

# Script para rodar em background - WhatsApp Sender Web
# Desenvolvido por Edimar Nery

# Ativar ambiente virtual
source venv/bin/activate

# Definir variáveis de ambiente
export FLASK_APP=src/main.py
export FLASK_ENV=production
export PYTHONPATH=$(pwd)

# Iniciar aplicação em background
nohup python -m flask run --host=0.0.0.0 --port=5000 > app.log 2>&1 &

echo "WhatsApp Sender Web iniciado em background!"
echo "PID: $!"
echo "Log: tail -f app.log"
echo "URL: http://localhost:5000"
echo ""
echo "Para parar: pkill -f 'flask run'"
EOF

chmod +x start_background.sh

# Criar script de parada
log "Criando script de parada..."
cat > stop.sh << 'EOF'
#!/bin/bash

echo "Parando WhatsApp Sender Web..."
pkill -f 'flask run'
echo "Aplicação parada!"
EOF

chmod +x stop.sh

# Criar serviço systemd (opcional)
log "Criando arquivo de serviço systemd..."
cat > whatsapp-sender-web.service << EOF
[Unit]
Description=WhatsApp Sender Web
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$(pwd)
Environment=FLASK_APP=src/main.py
Environment=FLASK_ENV=production
Environment=PYTHONPATH=$(pwd)
ExecStart=$(pwd)/venv/bin/python -m flask run --host=0.0.0.0 --port=5000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Testar instalação
log "Testando instalação..."
source venv/bin/activate
python -c "import flask, pandas, selenium; print('✅ Todas as dependências instaladas com sucesso!')"

echo ""
echo "=========================================="
echo "  🎉 INSTALAÇÃO CONCLUÍDA!"
echo "=========================================="
echo ""
echo "📱 Como usar:"
echo ""
echo "🚀 Iniciar aplicação:"
echo "   ./start.sh                    # Modo interativo"
echo "   ./start_background.sh         # Modo background"
echo ""
echo "⏹️  Parar aplicação:"
echo "   Ctrl+C                        # Se modo interativo"
echo "   ./stop.sh                     # Se modo background"
echo ""
echo "📋 Instalar como serviço (opcional):"
echo "   sudo cp whatsapp-sender-web.service /etc/systemd/system/"
echo "   sudo systemctl enable whatsapp-sender-web"
echo "   sudo systemctl start whatsapp-sender-web"
echo ""
echo "🌐 Acesso:"
echo "   http://localhost:5000"
echo "   http://$(hostname -I | awk '{print $1}'):5000"
echo ""
echo "📝 Logs:"
echo "   tail -f app.log               # Se modo background"
echo "   sudo journalctl -u whatsapp-sender-web -f  # Se serviço"
echo ""
echo "🔧 Desenvolvido por Edimar Nery"
echo "=========================================="

