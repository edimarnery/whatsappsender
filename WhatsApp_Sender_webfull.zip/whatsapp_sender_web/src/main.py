from flask import Flask, render_template, request, jsonify, send_file, session
from flask_cors import CORS
import pandas as pd
import os
import time
import threading
import random
import re
from datetime import datetime
from urllib.parse import quote
import webbrowser
import uuid
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'whatsapp_sender_secret_key_2025'
CORS(app)

# Configurações
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'xlsx', 'xls'}
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size

# Criar diretórios necessários
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs('logs', exist_ok=True)

# Variáveis globais para controle de envio
envio_status = {}
envio_threads = {}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def validar_numero(numero):
    """Valida formato do número de telefone"""
    numero_limpo = re.sub(r'[^\d+]', '', str(numero))
    if re.match(r'^\+\d{10,15}$', numero_limpo):
        return numero_limpo
    return None

def processar_planilha(df):
    """Processa a planilha para o formato esperado"""
    try:
        colunas = [col.upper().strip() for col in df.columns]
        
        if all(col in colunas for col in ['NOME', 'DDD', 'CELULAR']):
            df_processado = df.copy()
            df_processado['DDD'] = df_processado['DDD'].astype(str)
            df_processado['CELULAR'] = df_processado['CELULAR'].astype(str)
            df_processado['NUMERO_COMPLETO'] = '+55' + df_processado['DDD'] + df_processado['CELULAR']
            
            df_final = pd.DataFrame()
            df_final['NOME'] = df_processado['NOME']
            df_final['DDI + DDD + CELULAR'] = df_processado['NUMERO_COMPLETO']
            return df_final
            
        elif all(col in colunas for col in ['NOME', 'DDI + DDD + CELULAR']):
            return df
        else:
            raise ValueError("Formato de planilha não reconhecido")
            
    except Exception as e:
        raise Exception(f"Erro ao processar planilha: {str(e)}")

def calcular_delay(tipo_delay, delay_min, delay_max, delay_fixo, contador_envios, delay_extra):
    """Calcula delay baseado nas configurações"""
    if tipo_delay == "aleatorio":
        if delay_min > delay_max:
            delay_min, delay_max = delay_max, delay_min
            
        delay_base = random.randint(delay_min, delay_max)
        
        if delay_extra and contador_envios > 0 and contador_envios % 10 == 0:
            delay_extra_valor = random.randint(30, 60)
            return delay_base + delay_extra_valor, True
            
        return delay_base, False
    else:
        return delay_fixo, False

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'Nenhum arquivo enviado'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'Nenhum arquivo selecionado'}), 400
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{timestamp}_{filename}"
            filepath = os.path.join(UPLOAD_FOLDER, filename)
            file.save(filepath)
            
            # Processar planilha
            df_original = pd.read_excel(filepath)
            df = processar_planilha(df_original)
            df = df.dropna(subset=['NOME', 'DDI + DDD + CELULAR'])
            
            # Validar números
            numeros_validos = []
            for idx, row in df.iterrows():
                numero = validar_numero(row['DDI + DDD + CELULAR'])
                if numero:
                    numeros_validos.append(idx)
                    df.at[idx, 'DDI + DDD + CELULAR'] = numero
                    
            if not numeros_validos:
                return jsonify({'error': 'Nenhum número de telefone válido encontrado!'}), 400
                
            df = df.loc[numeros_validos]
            
            # Salvar dados processados na sessão
            session_id = str(uuid.uuid4())
            session['session_id'] = session_id
            session['df_path'] = filepath
            session['total_contatos'] = len(df)
            
            # Salvar DataFrame processado
            processed_path = os.path.join(UPLOAD_FOLDER, f"processed_{session_id}.xlsx")
            df.to_excel(processed_path, index=False)
            session['processed_path'] = processed_path
            
            # Carregar histórico de envios
            log_path = f"logs/log_envios_web_{session_id}.xlsx"
            enviados_count = 0
            if os.path.exists(log_path):
                try:
                    df_log = pd.read_excel(log_path)
                    enviados_set = set(df_log["Número"].astype(str))
                    enviados_count = len([n for n in df['DDI + DDD + CELULAR'].astype(str) if n in enviados_set])
                except:
                    pass
            
            pendentes = len(df) - enviados_count
            
            return jsonify({
                'success': True,
                'total_contatos': len(df),
                'enviados': enviados_count,
                'pendentes': pendentes,
                'session_id': session_id
            })
        
        return jsonify({'error': 'Tipo de arquivo não permitido'}), 400
        
    except Exception as e:
        return jsonify({'error': f'Erro ao processar arquivo: {str(e)}'}), 500

@app.route('/preview', methods=['POST'])
def preview_mensagens():
    try:
        data = request.get_json()
        mensagens = data.get('mensagens', [])
        session_id = session.get('session_id')
        
        if not session_id or 'processed_path' not in session:
            return jsonify({'error': 'Nenhum arquivo carregado'}), 400
        
        if not mensagens:
            return jsonify({'error': 'Nenhuma mensagem fornecida'}), 400
        
        # Carregar dados processados
        df = pd.read_excel(session['processed_path'])
        
        # Gerar preview com os primeiros 3 contatos
        preview_data = []
        for i, (_, row) in enumerate(df.head(3).iterrows()):
            nome = str(row['NOME']).strip()
            numero = str(row['DDI + DDD + CELULAR']).strip()
            msg_template = random.choice(mensagens)
            msg_personalizada = msg_template.format(nome=nome)
            
            preview_data.append({
                'contato': i + 1,
                'nome': nome,
                'numero': numero,
                'mensagem': msg_personalizada
            })
        
        return jsonify({'preview': preview_data})
        
    except Exception as e:
        return jsonify({'error': f'Erro ao gerar preview: {str(e)}'}), 500

@app.route('/iniciar_envio', methods=['POST'])
def iniciar_envio():
    try:
        data = request.get_json()
        session_id = session.get('session_id')
        
        if not session_id or 'processed_path' not in session:
            return jsonify({'error': 'Nenhum arquivo carregado'}), 400
        
        # Configurações do envio
        config = {
            'mensagens': data.get('mensagens', []),
            'tipo_delay': data.get('tipo_delay', 'aleatorio'),
            'delay_min': int(data.get('delay_min', 8)),
            'delay_max': int(data.get('delay_max', 15)),
            'delay_fixo': int(data.get('delay_fixo', 10)),
            'delay_extra': data.get('delay_extra', True),
            'delay_inicial': data.get('delay_inicial', True),
            'controle_janela': data.get('controle_janela', 'fechar_abrir')
        }
        
        if not config['mensagens']:
            return jsonify({'error': 'Nenhuma mensagem fornecida'}), 400
        
        # Inicializar status do envio
        envio_status[session_id] = {
            'ativo': True,
            'progresso': 0,
            'total': session['total_contatos'],
            'atual': '',
            'status': 'Iniciando...',
            'enviados': 0,
            'erros': 0
        }
        
        # Iniciar thread de envio
        thread = threading.Thread(
            target=processar_envio,
            args=(session_id, config),
            daemon=True
        )
        thread.start()
        envio_threads[session_id] = thread
        
        return jsonify({'success': True, 'session_id': session_id})
        
    except Exception as e:
        return jsonify({'error': f'Erro ao iniciar envio: {str(e)}'}), 500

def processar_envio(session_id, config):
    """Processa o envio das mensagens"""
    try:
        # Carregar dados
        processed_path = f"uploads/processed_{session_id}.xlsx"
        df = pd.read_excel(processed_path)
        
        # Carregar histórico de envios
        log_path = f"logs/log_envios_web_{session_id}.xlsx"
        enviados_set = set()
        if os.path.exists(log_path):
            try:
                df_log = pd.read_excel(log_path)
                enviados_set = set(df_log["Número"].astype(str))
            except:
                pass
        
        log = []
        contador_envios = 0
        
        # Delay inicial se configurado
        if config['delay_inicial']:
            delay_inicial = random.randint(5, 15)
            for j in range(delay_inicial):
                if not envio_status[session_id]['ativo']:
                    return
                envio_status[session_id]['status'] = f"🛡️ Delay inicial: {delay_inicial-j}s"
                time.sleep(1)
        
        # Processar cada contato
        for i, row in df.iterrows():
            if not envio_status[session_id]['ativo']:
                break
                
            nome = str(row['NOME']).strip()
            numero = str(row['DDI + DDD + CELULAR']).strip()
            
            # Pular contatos já enviados
            if numero in enviados_set:
                envio_status[session_id]['progresso'] = i + 1
                continue
                
            # Escolher mensagem aleatória e personalizar
            msg_template = random.choice(config['mensagens'])
            msg_personalizada = msg_template.format(nome=nome)
            
            try:
                envio_status[session_id]['status'] = f"Enviando para {nome}"
                envio_status[session_id]['atual'] = f"{nome} ({numero})"
                
                # Simular envio via WhatsApp Web (em produção, usar selenium ou API)
                # Por enquanto, apenas simular o processo
                time.sleep(2)  # Simular tempo de envio
                
                contador_envios += 1
                
                # Calcular delay para próximo envio
                delay_segundos, is_extra = calcular_delay(
                    config['tipo_delay'],
                    config['delay_min'],
                    config['delay_max'],
                    config['delay_fixo'],
                    contador_envios,
                    config['delay_extra']
                )
                
                # Aplicar delay
                for j in range(delay_segundos):
                    if not envio_status[session_id]['ativo']:
                        break
                    if is_extra:
                        envio_status[session_id]['status'] = f"🛡️ Delay extra: {delay_segundos-j}s"
                    else:
                        envio_status[session_id]['status'] = f"🎲 Delay: {delay_segundos-j}s"
                    time.sleep(1)
                    
                log.append([nome, numero, "Sucesso", datetime.now().strftime("%d/%m/%Y %H:%M:%S")])
                enviados_set.add(numero)
                envio_status[session_id]['enviados'] += 1
                
            except Exception as e:
                log.append([nome, numero, f"Erro: {str(e)}", datetime.now().strftime("%d/%m/%Y %H:%M:%S")])
                envio_status[session_id]['erros'] += 1
                
            envio_status[session_id]['progresso'] = i + 1
            
        # Salvar log
        if log:
            df_log = pd.DataFrame(log, columns=["Nome", "Número", "Status", "Data/Hora"])
            
            if os.path.exists(log_path):
                df_existente = pd.read_excel(log_path)
                df_log = pd.concat([df_existente, df_log], ignore_index=True)
                
            df_log.to_excel(log_path, index=False)
        
        # Finalizar
        if envio_status[session_id]['ativo']:
            envio_status[session_id]['status'] = "Envio concluído!"
        else:
            envio_status[session_id]['status'] = "Envio interrompido"
            
        envio_status[session_id]['ativo'] = False
        
    except Exception as e:
        envio_status[session_id]['status'] = f"Erro: {str(e)}"
        envio_status[session_id]['ativo'] = False

@app.route('/status_envio')
def status_envio():
    session_id = session.get('session_id')
    if session_id and session_id in envio_status:
        return jsonify(envio_status[session_id])
    return jsonify({'error': 'Nenhum envio ativo'}), 404

@app.route('/parar_envio', methods=['POST'])
def parar_envio():
    session_id = session.get('session_id')
    if session_id and session_id in envio_status:
        envio_status[session_id]['ativo'] = False
        envio_status[session_id]['status'] = "Solicitando parada..."
        return jsonify({'success': True})
    return jsonify({'error': 'Nenhum envio ativo'}), 404

@app.route('/log')
def ver_log():
    try:
        session_id = session.get('session_id')
        if not session_id:
            return jsonify({'error': 'Nenhuma sessão ativa'}), 400
        
        log_path = f"logs/log_envios_web_{session_id}.xlsx"
        if not os.path.exists(log_path):
            return jsonify({'log': [], 'estatisticas': {'total': 0, 'sucessos': 0, 'erros': 0}})
        
        df_log = pd.read_excel(log_path)
        
        # Estatísticas
        total_envios = len(df_log)
        sucessos = len(df_log[df_log['Status'] == 'Sucesso'])
        erros = total_envios - sucessos
        
        # Converter para lista de dicionários
        log_data = df_log.to_dict('records')
        
        return jsonify({
            'log': log_data,
            'estatisticas': {
                'total': total_envios,
                'sucessos': sucessos,
                'erros': erros
            }
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao carregar log: {str(e)}'}), 500

@app.route('/download_log')
def download_log():
    try:
        session_id = session.get('session_id')
        if not session_id:
            return jsonify({'error': 'Nenhuma sessão ativa'}), 400
        
        log_path = f"logs/log_envios_web_{session_id}.xlsx"
        if not os.path.exists(log_path):
            return jsonify({'error': 'Log não encontrado'}), 404
        
        return send_file(log_path, as_attachment=True, download_name=f"log_envios_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx")
        
    except Exception as e:
        return jsonify({'error': f'Erro ao baixar log: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

